// رابط البوت الخاص بك سيظهر هنا تلقائياً عند التشغيل
const dashboardURL = "انتظر تشغيل البوت...";
console.log("لوحة التحكم: ", dashboardURL);
