module.exports.config = {
    name: "بينج",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Hitler",
    description: "فحص سرعة استجابة البوت",
    commandCategory: "النظام",
    usages: "",
    cooldowns: 5
};

module.exports.run = async function({ api, event }) {
    return api.sendMessage("بونج! 🏓 البوت يعمل بنجاح.", event.threadID, event.messageID);
};